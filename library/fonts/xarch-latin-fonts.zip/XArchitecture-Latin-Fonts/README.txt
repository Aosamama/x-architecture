X ARCHITECTURE
حزمة الخطوط اللاتينية  |  Latin Fonts Pack
==========================================

AR
هذي الخطوط مفتوحة المصدر ومجانية للاستخدام الشخصي والتجاري (لوحات، بوسترات، عروض، مشاريع تخرج).
الترخيص: SIL Open Font License 1.1 (OFL). نصه داخل مجلد كل خط (OFL.txt) مع اسم صاحب الحقوق.
تقدر تستعملها وتعدّل عليها وتشاركها، بشرط إبقاء ملف الترخيص معها. ممنوع بيع الخط لوحده.
المصدر: مستودع Google Fonts الرسمي  https://github.com/google/fonts
ملاحظة: الخطوط المسمّاة Variable خط واحد فيه كل الأوزان. برامج Adobe الحديثة تدعمها، وإذا برنامجك ما يدعمها ثبّت الخطوط الثابتة (Static) إن وُجدت بالحزمة.

EN
Open-source fonts, free for personal and commercial work (boards, posters, presentations, graduation projects).
Licence: SIL Open Font License 1.1 (OFL). The licence text and the copyright holder are in each font's folder (OFL.txt).
You may use, modify and share them as long as the licence file stays with them. Do not sell a font by itself.
Source: the official Google Fonts repository  https://github.com/google/fonts
Note: files named Variable hold every weight in one font. Current Adobe apps support them; if your software does not, use the static fonts where the pack has them.

Included / المحتويات
  - Jost: Variable (wght 100-900)
  - Montserrat: Variable (wght 100-900)
  - Josefin Sans: Variable (wght 100-700)
  - Raleway: Variable (wght 100-900)
  - Inter: Variable (wght 100-900, opsz 14-32)

Packed by X Architecture  |  xarch.site
